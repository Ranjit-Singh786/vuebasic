<!-- <template>
  <div>
    <section class="p-0">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 p-0">
                    <div class="navbar-dashboard d-flex justify-content-between">
                        <div class="dashboard-logo ">
                                <router-link to="/"><img src="@/assets/images/homeimages/logo.png" class="img-fluid" alt="logo"></router-link>
                            </div>
                            <div class="logout-button d-flex justify-content-end p-4">
                                <button type="button" class=" px-4 py-2">Logout</button>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
  </div>
</template>

<script>
export default {
    name:'HeaderComponent'
}
</script>

<style scoped>
.dashboard-page {
    background-color: var(--home-bg);
    min-height:100vh;
}

.dashboard-logo {
    padding: 17px 10px;
}
.logout-button button{
    border-radius: 4px;
    background-color: var(--white);
    font-weight: 300;
    font-size:var(--fs-3) ;
    color: var(--navy-blue);
    border: 2px solid transparent;
}
.logout-button button:hover{
    background-color: transparent;
    border:2px solid var(--white);
    color: var(--white);
    cursor: pointer;
}
.navbar-dashboard{
    background-color: var(--navy-blue);
}
</style>  -->