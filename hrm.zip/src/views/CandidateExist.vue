<template>
  <div>
    <DashboardLayout>
      <!-- ***************************************dashbpoard-content************************************************** -->
<!-- <router-view /> -->
      <div class="dashbpoard-content px-0 px-md-5 py-4">
      <!-- *******team-heading******* -->
          <div class="d-flex justify-content-between align-items-center mb-3 px-3 px-md-0">
            <div class="user-head px-3 px-md-0">
              <h2 class="m-0 mb-md-3">Candidate details :</h2>
            </div>
            </div>
          <!-- Interview-form -->
          <div class="interview-form py-4 px-3 px-lg-4">
          <form @submit.prevent="get_can_fetch">
            <div class="interview-head">
              <h3 class="m-0 text-center mb-4">Fill the details</h3>
            </div>
            <div class="row justify-content-center">
               
                <div class="col-md-4">
                  <div class="username mb-3">
                    <label for="label">Email:</label>
                  <input type="text" v-model="email" class="form-control" placeholder="Enter email">
                     <span class="text-danger" v-if="v$.email.$error">{{
                                  v$.email.$errors[0].$message
                                }}</span>
                  </div>
                </div>
            </div>
            <div class="row justify-content-center">
                  <div class="col-md-4">
                  <p class="text-center mt-3 fw-bold">or</p>
                  <div class="username mb-3">
                    <label for="label">Mobile:</label>
                  <input type="text" @keypress="onlyNumbers" v-model="mobile"  class="form-control" placeholder="Enter mobile">
                     <span class="text-danger" v-if="v$.mobile.$error">{{
                                  v$.mobile.$errors[0].$message
                                }}</span>
                  </div>
                </div>
              </div>
             
                <div class="row bank-row justify-content-center">
                                    <div class="col-md-10 col-lg-4 col-xl-4">
                                        <div class="my-5 text-center">
                            
                              <button v-if="loadingadd == false" type="submit" class="px-5 py-2 modal-btn">
                                                Save
                                            </button>
                                            <button class="px-5 py-2 modal-btn" type="button" v-else>
                                                <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                            </button>
                           
                            </div>
                            </div>
                            </div>
            
            </form>
          </div>
          <div v-if="load">
            <div class="department-table mt-2" >
                <div class="row">
                  <div class="col-md-12">
                    <div class="table-responsive department-table">
                      <table class="table align-middle">
                        <thead>
                          <tr class="table-head text-center">
                            <th>Sr.No.</th>
                            <th>name</th>
                            <th>email</th>
                            <th>mobile</th>
                          </tr>
                        </thead>
                        <tbody>
                           <tr v-if="data.length ==0">
                                    <td colspan="10">
                                        <div v-if="loadingloader">
                                            <div v-for="(index) in 5" :key="index" class="my-4">
                                            <Skeletor height="15" pill :shimmer="true"/>
                                            </div>
                                        </div>
                                        <span v-else class=" text-light text-center mb-3 p-2">
                                            <h5 class="mb-0 text-success"> No Data Available</h5>
                                        
                    <div class="candidate-btn-11 mt-3">
                    <div class=" text-center "><button @click="candidate_route" class="px-5 py-2 modal-btn">Add candidate</button></div>
                  
                  </div>
                                        </span>
                                    </td>
                                </tr>
                          <tr class="text-center department-action" v-for="(can,index) in data" :key="index">
                            <td>{{index+1}}</td>
                            <td>{{can.name}}</td>
                            <td>{{can.email}}</td>
                            <td>{{can.mobile_number}}</td>
                            
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
                
              </div>
          </div>
      </div>
    </DashboardLayout>
  </div>
</template>

<script>
import DashboardLayout from "@/Layout/DashboardLayout";
import useVuelidate from "@vuelidate/core";
import {email,  helpers ,requiredIf} from "@vuelidate/validators";
import ApiClass from '@/api/api.js';
export default {
  name: "CandidateExists",
  components: {
    DashboardLayout,

  },
  data(){
    return{
    loadingadd:false,
    email:'',
    mobile:'',
    load:false,
    indatestatus:true,
    mobilestatus:true,
    data:""
    }
  },
  computed:{

  },
  validations(){
    return{
   email: { required: helpers.withMessage("Email is required",
    requiredIf(!this.mobile)),
     email: helpers.withMessage(
            "Email must be a valid email address",
            email
          ), },
  
   mobile: { required: helpers.withMessage("Mobile is required", requiredIf(!this.email)) },
   
    }
  },
   setup() {
        return {
            v$: useVuelidate(),
        };
    },
  methods:{
    candidate_route(){
          this.$router.push({ name: 'CandidateViews', params: { state: true }});
    },
     async get_can_fetch() {
       
       const result = await this.v$.$validate();
            if (!result) {
                return;
            }
            this.load = true;
            this.loadingloader = true;
      let response = await ApiClass.getNodeRequest("candidate-fetch?email="+this.email+ "&mobile_number=" + this.mobile, true);

      if (response?.data) {
        //  this.load = true;
        this.loadingloader = false;
        // console.log(response);
          
          this.data = response.data ?? [];
          console.log(this.data.length);
          // this.data.length!=0? :this.laod = false;
          console.log(this.data);
      
       
      }
    },
    onlyNumbers(event) {
            if (!/^[0-9]+$/.test(event.key)) {
                this.ignoredValue = event.key ? event.key : "";
                var charCode = event.which ? event.which : event.keyCode;
                if (
                    charCode > 31 &&
                    (charCode < 48 || charCode > 57) &&
                    charCode !== 46
                ) {
                    event.preventDefault();
                } else {
                    return true;
                }
            }
        },
  }
  
   
  
 
  
};
</script>
<style scoped>

.dashbpoard-content{
    background-color: var(--hr-bg);
    min-height:calc(100vh - 142px);
}
.interview-form{
    box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
    border-radius: 4px;
    background-color: var(--white);
}
.interview-head h3{
  font-size: var(--fs-5);
  font-weight: 600;
  color:var(--navy-blue);
}
.username label{
    font-size: var(--fs-3);
    color:var(--navy-blue);
    padding-bottom: 4px;
    font-weight: bolder;
}
.username select, .username input{
  color:var(--text-box);
  font-size: var(--fs-3);
  padding: 4px 8px;
}
.username input, .username select:focus{
  box-shadow: none;
  border:1px solid var(--hr-border);
}
  .user-head h2 {
    font-size: var(--fs-4);
    font-weight: 600;
    color: var(--navy-blue);
  }
/**********************************submit-btn************************************/
.modal-btn{
    background-color: var(--navy-blue);
    color: var(--white);
    border:transparent;
    border-radius: 4px;
    font-weight: 500;
    border:2px solid transparent;
}
.modal-btn:hover{
    background-color: transparent;
    color: var(--navy-blue);
    border:2px solid var(--navy-blue);
    border-radius: 4px;
}
.candidates-header{
  background-color: var(--navy-blue);
  color:var(--white)
}
  /****************************pagination-style*****************************/
  .page-link {
      color: var(--text-box);
      font-size: var(--fs-3);
  }
  .page-link:focus {
      box-shadow: none;
  }
  .candidate-btn{
    background-color: var(--navy-blue);
  }
 /***************************media responsive**********************************/
@media all and (min-width:1200px) and (max-width:1400px){
.dashbpoard-content {
  height:calc(100% - 143px);
}
}
@media all and (min-width:1025px) and (max-width:1199px){
.dashbpoard-content {
  height:calc(100% - 143px);
}
}
@media all and (min-width:992px) and (max-width:1024px){
.dashbpoard-content {
  height:calc(100% - 143px);
}
}
@media all and (min-width:768px) and (max-width:991px){
.dashbpoard-content {
  height:calc(100% - 160px);
}
}
@media all and (min-width:320px) and (max-width:767px){
.dashbpoard-content {
  height:calc(100% - 160px);
}
}
</style>